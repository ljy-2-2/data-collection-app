import sys,time,json,threading,importlib.util
from pathlib import Path
from types import SimpleNamespace
APP=Path('/opt/xiaokai-lab-data-collection/app')
sys.path.insert(0,str(APP/'fusion_camera_stream'));sys.path.insert(0,str(APP/'teleop_control/src'))
from fusion_camera import FusionStreamClient
from teleop_control.tianji_camera_session import CameraSession
spec=importlib.util.spec_from_file_location('candidate_collector',APP/'fusion_data_collection/FusionDataCollector/collector.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
ROOT=Path('/opt/xiaokai-continuous-camera-20261109');results=[];received={k:[] for k in ('usb-1','usb-2','usb-4')};boundaries=[];failure=[]
def client():return FusionStreamClient('192.168.1.190',credentials='/home/orangepi/.config/xiaokai-lab-data-collection/tianji-camera/client.json',timeout=5)
c=client();status=c.status();assert status['idle'];
if status['fault']:c.recheck_cameras()
s=CameraSession(c,c.clock_sync(3),client)
def reader():
 try:
  for e in c.stream(seconds=0,mode='teleop_observation',isolate_joint_feedback=True):
   s.publish(e)
   if e.metadata['type']=='image':received[e.metadata['camera_id']].append((time.monotonic(),e.metadata['sequence']))
   if e.metadata['type']=='checkpoint':boundaries.append((time.monotonic(),dict(e.metadata)))
  s.finish()
 except Exception as ex:failure.append(str(ex));s.finish(ex)
t=threading.Thread(target=reader,daemon=True);t.start()
try:
 until=time.monotonic()+20
 while time.monotonic()<until:
  if failure:raise RuntimeError(failure)
  if all(s.fresh.get(k) for k in received) and s.joint_time:break
  time.sleep(.05)
 else:raise RuntimeError('No live frames')
 print('Three continuous cameras and real joints ready',flush=True)
 for i in range(3):
  args=SimpleNamespace(output=str(ROOT/'diagnostic-episodes'),task='diagnostic_only_no_training',max_seconds=0,retain_native=False,controlled_sides=(),record_actions=False,adopt_camera_stream=True,camera_ids=list(received),camera_profiles=s.start.metadata['camera_profiles'])
  trigger=dict(sequence=0,session='passive-camera-validation',pc_monotonic_ns=time.monotonic_ns(),button_press_counts={},vr_connected=False)
  ep=mod.Episode(args,dict(zip(received,('head_color','right_color','left_color'))),trigger,client_factory=s.subscribe,episode_index=i+1)
  ep.start();limit=time.monotonic()+10
  while ep.state!='recording' and not ep.finished.is_set() and time.monotonic()<limit:time.sleep(.02)
  assert ep.state=='recording',ep.error
  time.sleep(3)
  stopped=time.monotonic();ep.stop('diagnostic_boundary');ep.join(20)
  assert not ep.is_alive() and ep.error is None,ep.error
  meta=json.loads((ep.directory/'meta_info.json').read_text());end=json.loads((ep.directory/'record/stream_end.json').read_text())
  assert meta['complete'] and meta['integrity']['record_count_matches_server'],meta.get('error')
  assert end['transport_continues'] and end['native_exit'] is None and not s.finished.is_set() and t.is_alive()
  cams=meta['integrity']['cameras'];joints=meta['integrity']['joints']
  row=dict(episode=str(ep.directory),boundary_ms=(boundaries[-1][0]-stopped)*1000,finalized_ms=(time.monotonic()-stopped)*1000,
   frames={k:v['frames'] for k,v in meta['cameras'].items()},rates={k:v.get('actual_hz') for k,v in cams.items()},joints=joints,
   counts_match=True,checkpoint=end['checkpoint_id'],clock_before=json.loads((ep.directory/'record/clock_before.json').read_text()),clock_after=json.loads((ep.directory/'record/clock_after.json').read_text()))
  results.append(row);print(json.dumps(row),flush=True)
  with open(ROOT/'live-test-results.json','w') as f:json.dump({'episodes':results,'failure':failure},f)
 assert not failure,failure
 summary={'episodes':results,'failure':failure,'camera_max_receive_gap_ms':{k:max((b[0]-a[0])*1000 for a,b in zip(v,v[1:])) for k,v in received.items()},'camera_sequence_regressions':{k:sum(b[1]<=a[1] for a,b in zip(v,v[1:])) for k,v in received.items()},'hardware_streams_started':1}
 with open(ROOT/'live-test-results.json','w') as f:json.dump(summary,f)
 print('SUMMARY',json.dumps({k:v for k,v in summary.items() if k!='episodes'}),flush=True)
finally:
 c.request_stop();t.join(15);c.close()
 print('Transport ended after test:',bool(s.end),'error:',failure,flush=True)
