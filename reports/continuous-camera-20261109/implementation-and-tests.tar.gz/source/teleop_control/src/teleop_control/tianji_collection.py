"""Tianji A/B collection, reusing the app's Episode writer and upload queue."""

from __future__ import annotations

import copy
import json
import sys
import threading
import time
import uuid
from pathlib import Path
from types import SimpleNamespace

from .collection_uploader import READY_MARKER
from .robot_names import TIANJI_DISPLAY_NAME
from .collection_gate import collection_available, collection_context
from .platform_auth import current_platform_username

APP_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(APP_ROOT / "fusion_camera_stream"))
sys.path.insert(0, str(APP_ROOT / "fusion_data_collection"))
from FusionDataCollector.collector import Buttons, Episode, dump, finite_number, readiness  # noqa: E402

CAMERA_MAPPING = {"usb-1": "head_color", "usb-2": "right_color", "usb-4": "left_color"}


class TianjiCollection:
    def __init__(self, manager, output=None, episode_factory=Episode):
        self.manager = manager
        self.output = Path(output or APP_ROOT / "teleop_control/runtime/tianji/episodes")
        from .tianji_local_queue import configured_root, destination
        self.queue_root = configured_root() if output is None else None
        self.saved_output = destination(self.queue_root) if self.queue_root else self.output
        if self.queue_root:
            self.output = self.queue_root / 'pending'
        self.app_run_id, self.app_run_lock = '', None
        if self.queue_root:
            from .tianji_run_storage import begin_run
            self.app_run_id, self.app_run_lock = begin_run(self.queue_root)
        self.submitted = 0
        self.episode_factory = episode_factory
        self.lock = threading.RLock()
        self.done = threading.Event()
        self.job = None
        self.episode = None
        self.latest = None
        self.armed = False
        self.phase = "idle"
        self.error = ""
        self.completed = 0
        self.uploader = None
        self.buttons = Buttons()
        self.session = ""
        self.task = ""
        self.controlled_sides = ("left", "right")
        self.upload_sides = ("left", "right")
        self.parameters = {}
        self.owner = "unknown"
        self.last_episode = None
        self.last_gripper_fault = None
        self.gripper_fault_active = False
        self.gripper_action_cache = {}
        self.gripper_action_session = None

    def arm(self, request):
        with self.lock:
            if self.active():
                raise RuntimeError("上一轮数据尚在保存，请稍后再开始遥操作")
            self.session = uuid.uuid4().hex
            self.completed = 0
            self.submitted = 0
            self.episode = None
            self.last_episode = None
            self.task = request["task"]
            mode = request.get("mode", "dual")
            self.controlled_sides = ("left", "right") if mode == "dual" else (mode,)
            upload_mode = request.get("upload_mode") or mode
            self.upload_sides = ("left", "right") if upload_mode == "dual" else (upload_mode,)
            self.parameters = dict(request.get("parameters", {}))
            self.owner = current_platform_username()
            self.buttons = Buttons(annotation=bool(request.get("subtask_config")))
            self.subtask_config = copy.deepcopy(request.get("subtask_config"))
            self.latest = None
            self.gripper_action_cache = {}
            self.gripper_action_session = None
            self.armed, self.phase, self.error = True, "ready", ""
            self.done.clear()

    def active(self):
        return bool(self.job and self.job.is_alive())

    def _gripper_action_reference(self, row):
        """G2-style recording cache; never write a target into motor control state."""
        if row.get("session") != self.gripper_action_session:
            self.gripper_action_cache.clear()
            self.gripper_action_session = row.get("session")
        stamp = row.get("pc_monotonic_ns")
        motors = (row.get("grippers") or {}).get("motors") or {}
        live = (row.get("mode") == "live" and row.get("teleop_state") == "running"
                and not (row.get("grippers") or {}).get("fault")
                and finite_number(stamp) and 0 <= time.monotonic_ns() - stamp <= 300_000_000)
        references = {}
        for side in self.controlled_sides:
            motor = motors.get(side) or {}
            fb = motor.get("feedback") or {}
            fresh = (live and finite_number(fb.get("position"))
                     and finite_number(fb.get("received"))
                     and 0 <= stamp / 1e9 - fb["received"] <= .15
                     and fb.get("state") in (0, 1))
            target_available = (fresh and finite_number(motor.get("target_rad"))
                                and motor.get("state") in ("ACTIVE", "ENABLING"))
            if fresh and side not in self.gripper_action_cache:
                self.gripper_action_cache[side] = dict(
                    position_rad=fb["position"], source="initial_feedback",
                    source_pc_monotonic_ns=round(fb["received"] * 1e9))
            if target_available:
                self.gripper_action_cache[side] = dict(
                    position_rad=motor["target_rad"], source="last_controller_target",
                    source_pc_monotonic_ns=stamp)
            references[side] = dict(
                self.gripper_action_cache.get(side, dict(position_rad=None, source="unavailable",
                                                         source_pc_monotonic_ns=None)),
                controller_target_available=bool(target_available),
            )
        return references

    def accept(self, row):
        # Runs in the SDK IPC reader: never wait for cameras, disk or uploads here.
        with self.lock:
            self.latest = row
            grippers = row.get("grippers") or {}
            fault = bool(grippers.get("fault"))
            if fault and not self.gripper_fault_active:
                # Retain the first fault frame after control stops, without disk
                # I/O in the SDK reader or replacing it with recovery feedback.
                self.last_gripper_fault = {
                    "pc_monotonic_ns": row.get("pc_monotonic_ns"),
                    "pc_unix_ns": row.get("pc_unix_ns"),
                    "teleop_state": row.get("teleop_state"),
                    "grippers": copy.deepcopy(grippers),
                }
            self.gripper_fault_active = fault
            if not self.armed:
                return
            row = dict(row, gripper_action_reference=self._gripper_action_reference(row))
            self.latest = row
            action = self.buttons.accept(row)
            if self.active() and self.episode:
                self.episode.submit(row)
                if action == "stop":
                    self.episode.stop("B/Y")
                if not self.episode.stopping.is_set():
                    reason = readiness(row, required_sides=self.controlled_sides)
                    if row.get("teleop_state") != "running":
                        reason = "遥操作已停止或发生故障"
                    if reason:
                        self.episode.stop("feedback_not_ready", reason)
            elif action == "start":
                try:
                    self.start()
                except (ValueError, RuntimeError) as exc:
                    self.error = str(exc)

    def start(self):
        if not collection_available():
            return
        with self.lock:
            if self.active():
                return
            if not self.armed or not self.latest or self.latest.get("teleop_state") != "running":
                raise ValueError("请先开始遥操作，等待手柄和机械臂反馈就绪")
            reason = readiness(self.latest, required_sides=self.controlled_sides)
            if reason:
                raise ValueError(reason)
            if self.queue_root:
                from .tianji_local_queue import require_worker
                require_worker(self.queue_root)
            context = collection_context()
            camera_state = (self.manager.collection_camera_state() if hasattr(self.manager, 'collection_camera_state')
                            else dict(ids=list(CAMERA_MAPPING), profiles=None))
            camera_mapping = {key: CAMERA_MAPPING[key] for key in camera_state['ids']}
            args = SimpleNamespace(
                output=str(self.output),
                task=self.task,
                subtask_config=getattr(self, "subtask_config", None),
                max_seconds=0,
                retain_native=False,
                controlled_sides=self.controlled_sides,
                robot_type="tianji",
                robot_name=TIANJI_DISPLAY_NAME,
                parameters=self.parameters,
                coordinate_mapping=copy.deepcopy(
                    getattr(self.manager, "value", {}).get("coordinate_mapping")
                ),
                teleop_runtime_mapping=copy.deepcopy(self.latest.get('teleop_mapping')),
                camera_ids=camera_state['ids'],
                camera_profiles=camera_state['profiles'],
                record_actions=True,
                gripper_action_policy="initial_feedback_then_last_target",
                recover_camera=False,
                adopt_camera_stream=True,
                on_stream_released=self.manager.resume_cameras_after_episode,
            )
            self.episode = self.episode_factory(
                args,
                camera_mapping,
                self.latest,
                client_factory=self.manager.adopt_camera_stream,
                episode_index=(self.submitted if self.queue_root else self.completed) + 1,
            )
            self.phase, self.error = "starting", ""
            # Capture session ownership before this background operation begins.
            info = {
                "import_task_id": "tianji-" + self.session,
                "import_folder": self.task,
                "teleop_session_id": self.session,
                "requested_cameras": list(camera_mapping.values()),
                "source": "teleop",
                "collection_trigger": "controller",
                "author": self.owner,
                "upload_sides": list(self.upload_sides),
                **({"upload_camera_policy":"selected_wrist_optional_head_v1"}
                   if len(self.controlled_sides)==1 else {}),
                **context,
            }
            if self.queue_root:
                args.app_run_id = self.app_run_id
                info['app_run_id'] = self.app_run_id
                args.background_finalize_root = str(self.queue_root)
                args.background_finalize_info = info
            self.job = threading.Thread(
                target=self._record, args=(self.episode, info), name="tianji-episode", daemon=True
            )
            self.job.start()

    def _record(self, episode, info):
        try:
            if episode.stopping.is_set():
                raise RuntimeError(episode.error or "开始采集前已收到结束指令")
            episode.run()
            if getattr(episode, 'background_queued', False):
                with self.lock:
                    self.submitted += 1
                    self.phase = 'queued'
                return
            if episode.error:
                raise RuntimeError(episode.error)
            metadata = json.loads((episode.directory / "meta_info.json").read_text())
            if not metadata.get("complete") or not metadata.get("actions_recorded"):
                raise RuntimeError("本轮数据不完整，已保留本地文件，不加入上传队列")
            metadata["author"] = info["author"]
            metadata["teleop_session_id"] = info["teleop_session_id"]
            metadata["upload_sides"] = info["upload_sides"]
            if "upload_camera_policy" in info:
                metadata["upload_camera_policy"] = info["upload_camera_policy"]
            if "upload_destination" in info:
                metadata["upload_destination"] = info["upload_destination"]
            dump(episode.directory / "meta_info.json", metadata)
            # Last write: the uploader must never see a partially written Episode.
            dump(episode.directory / READY_MARKER, info)
            with self.lock:
                self.completed += 1
                self.phase = "saved"
        except Exception as exc:
            episode.error = episode.error or str(exc)
            episode.finished.set()
            with self.lock:
                self.error, self.phase = str(exc), "incomplete"
            if self.queue_root:
                from .tianji_run_storage import register_incomplete
                register_incomplete(self.queue_root, self.app_run_id, episode, episode.error, info['teleop_session_id'])
        finally:
            with self.lock:
                self.last_episode = str(self.saved_output / getattr(episode, 'output_relative', episode.directory.name)) if episode.directory else None
            if self.armed and not self.done.is_set():
                self.manager.resume_cameras_after_episode()

    def stop(self, reason="B/Y", error=None):
        with self.lock:
            if self.active() and self.episode:
                self.episode.stop(reason, error)

    def disarm(self, reason="teleop_stopped"):
        with self.lock:
            self.armed = False
            # Closing after B must not convert an already stopped recording into an error.
            already_stopped = self.episode is not None and self.episode.stopping.is_set()
            self.stop(reason, None if already_stopped else "遥操作已结束，本轮未通过 B 键正常收尾")

    def snapshot(self):
        with self.lock:
            ep = self.episode
            phase = ep.state if self.active() and ep and not ep.finished.is_set() else self.phase
            ended = getattr(ep, "recording_ended_monotonic", None) if ep else None
            stop_ns = getattr(ep, "stop_pc_ns", None) if ep else None
            if stop_ns is not None:
                ended = min(ended, stop_ns / 1e9) if ended is not None else stop_ns / 1e9
            if ep and (ep.stopping.is_set() or ended is not None) and self.active():
                phase = "finalizing"
            if not self.armed and not self.active() and phase == "ready":
                phase = "idle"
            started = ep.started_monotonic if ep else None
            elapsed = max(0., (ended if ended is not None else time.monotonic()) - started) if started is not None else 0.
            local_save = None
            if self.queue_root:
                from .tianji_local_queue import queue_status
                local_save = queue_status(self.queue_root, self.session, self.app_run_id)
                self.completed = local_save['saved']
            return {
                **({'local_save': local_save} if local_save else {}),
                "state": phase,
                "armed": self.armed,
                "busy": self.active(),
                "recording": phase == "recording",
                "error": self.error,
                "completed": self.completed,
                "episode": ep.directory.name if ep and ep.directory else None,
                "elapsed_s": elapsed,
                "frames": dict(ep.frame_counts) if ep else {},
                "last_episode": self.last_episode,
                "last_gripper_fault": copy.deepcopy(self.last_gripper_fault),
                "upload": self.uploader.status()
                if self.uploader
                else {"pending": 0, "uploaded": 0, "failed": 0},
            }

    def close(self):
        self.disarm("app_closed")
        self.done.set()
        if self.job:
            self.job.join(timeout=25)
            if self.job.is_alive():
                raise RuntimeError("数据仍在保存，请稍后再返回配置")

    def finish_app_run(self):
        # Only main's process shutdown calls this, not returning to the setup page.
        if self.queue_root and not self.active():
            from .tianji_run_storage import end_run
            end_run(self.queue_root, self.app_run_id, self.app_run_lock)
