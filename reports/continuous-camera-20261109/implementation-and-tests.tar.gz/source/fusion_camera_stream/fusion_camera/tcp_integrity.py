"""ARM package camera TCP receive validation.

The filter belongs only to the camera socket. Invalid TCP checksums are dropped
before TCP acknowledges the segment, allowing normal retransmission. TLS stays
fully enabled. Requires IPv4, standard headers, MTU <=1500 and GRO disabled on
the dedicated camera interface. Other packet forms retain kernel handling.
"""
import functools
import socket

@functools.lru_cache(maxsize=4)
def program(low, high, link_offset=0, socket_filter=False):
    code, labels, jumps = [], {}, []
    def emit(op, jt=0, jf=0, k=0):
        code.append([op, jt, jf, k])
    def jump(label):
        jumps.append((len(code), label)); emit(0x05)
    def require(op, value):
        emit(op, 1, 0, value); jump('allow')
    emit(0x30, k=0); require(0x15, 0x45)
    emit(0x30, k=9); require(0x15, 6)
    emit(0x28, k=6); emit(0x54, k=0x3fff); require(0x15, 0)
    emit(0x28, k=2); require(0x35, low)
    emit(0x25, 0, 1, high); jump('allow')
    emit(0x07); emit(0x80)
    if socket_filter:emit(0x04, k=20)
    elif link_offset:emit(0x14, k=link_offset)
    require(0x3d, 0)
    # IPv4 TCP pseudoheader, with the odd final byte included up front.
    emit(0x28, k=12); emit(0x07)
    for offset in (14, 16, 18):
        emit(0x28, k=offset); emit(0x0c); emit(0x07)
    emit(0x28, k=2); emit(0x14, k=20); emit(0x04, k=6)
    emit(0x0c); emit(0x07); emit(0x02, k=2)
    emit(0x28, k=2); emit(0x54, k=1); emit(0x15, 8, 0, 0)
    emit(0x28, k=2); emit(0x14, k=1); emit(0x07)
    emit(0x50, k=0); emit(0x64, k=8); emit(0x61, k=2)
    emit(0x0c); emit(0x07)
    offset=20
    while offset+16<=high:
        emit(0x28,k=2);emit(0x35,3,0,offset+16)
        emit(0x00,k=offset);emit(0x02,k=4);jump('tail')
        for word in range(offset,offset+16,2):
            emit(0x28,k=word);emit(0x0c);emit(0x07)
        offset+=16
    emit(0x00,k=offset);emit(0x02,k=4)
    labels['tail']=len(code)
    emit(0x87);emit(0x02,k=2)
    for word in range(0,16,2):
        emit(0x60,k=4);emit(0x04,k=word+2);emit(0x07)
        emit(0x28,k=2);emit(0x3d,1,0);jump('fold')
        emit(0x61,k=4);emit(0x48,k=word)
        emit(0x61,k=2);emit(0x0c);emit(0x02,k=2)
    labels['fold'] = len(code)
    emit(0x61,k=2)
    for _ in range(2):
        emit(0x87); emit(0x54, k=65535); emit(0x02, k=3)
        emit(0x87); emit(0x74, k=16); emit(0x61, k=3)
        emit(0x0c); emit(0x07)
    emit(0x15, 1, 0, 65535); emit(0x06, k=0 if socket_filter else 1)
    labels['allow'] = len(code); emit(0x06, k=0xffffffff if socket_filter else 0)
    for pos, label in jumps:
        code[pos][3] = labels[label]-pos-1
        assert code[pos][3] >= 0
    for row in code:
        if row[0] in (0x20,0x28,0x30,0x48,0x50):row[3]=(row[3]+link_offset)&0xffffffff
    assert len(code) <= 4096
    return code

def attach(sock):
    import ctypes
    if sock.family != socket.AF_INET:
        raise RuntimeError("相机接收保护需要 IPv4 连接")
    class Instruction(ctypes.Structure):
        _fields_=[('code',ctypes.c_ushort),('jt',ctypes.c_ubyte),('jf',ctypes.c_ubyte),('k',ctypes.c_uint)]
    class Filter(ctypes.Structure):
        _fields_=[('length',ctypes.c_ushort),('instructions',ctypes.POINTER(Instruction))]
    rows=program(40,1500,-0x100000,True)
    array=(Instruction*len(rows))(*(Instruction(*row) for row in rows))
    filt=Filter(len(rows),array)
    sock.setsockopt(1,26,bytes(filt))
