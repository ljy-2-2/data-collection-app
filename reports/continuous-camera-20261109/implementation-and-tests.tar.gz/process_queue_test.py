import sys,time,json,threading,importlib.util
from pathlib import Path
from types import SimpleNamespace
APP=Path('/opt/xiaokai-lab-data-collection/app')
sys.path.insert(0,str(APP/'fusion_data_collection'));sys.path.insert(0,str(APP/'fusion_camera_stream'));sys.path.insert(0,str(APP/'teleop_control/src'))
from fusion_camera import FusionStreamClient
from teleop_control.tianji_camera_session import CameraSession
spec=importlib.util.spec_from_file_location('candidate_collector',APP/'fusion_data_collection/FusionDataCollector/collector.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
ROOT=Path('/opt/xiaokai-continuous-camera-20261109');results=[];received={k:[] for k in ('usb-1','usb-2','usb-4')};boundaries=[];failure=[]
def client():return FusionStreamClient('192.168.1.190',credentials='/home/orangepi/.config/xiaokai-lab-data-collection/tianji-camera/client.json',timeout=5)
from teleop_control import tianji_local_queue as queue
import subprocess
queue_root=ROOT/'process-queue-validation';queue.configure(queue_root,ROOT/'process-queue-saved');jobs=[]
worker=subprocess.Popen([sys.executable,'-c',"import sys;sys.path.insert(0,'/opt/xiaokai-lab-data-collection/app/teleop_control/src');from teleop_control.tianji_local_queue import run_worker;run_worker(sys.argv[1])",str(queue_root)],stdout=open(ROOT/'process-worker.log','w'),stderr=subprocess.STDOUT)
c=client();status=c.status();assert status['idle'];
if status['fault']:c.recheck_cameras()
s=CameraSession(c,c.clock_sync(3),client)
def reader():
 try:
  for e in c.stream(seconds=0,mode='teleop_observation',isolate_joint_feedback=True):
   s.publish(e)
   if e.metadata['type']=='image':received[e.metadata['camera_id']].append((time.monotonic(),e.metadata['sequence']))
   if e.metadata['type']=='checkpoint':boundaries.append((time.monotonic(),dict(e.metadata)))
  s.finish()
 except Exception as ex:failure.append(str(ex));s.finish(ex)
t=threading.Thread(target=reader,daemon=True);t.start()
try:
 until=time.monotonic()+20
 while time.monotonic()<until:
  if failure:raise RuntimeError(failure)
  if all(s.fresh.get(k) for k in received) and s.joint_time:break
  time.sleep(.05)
 else:raise RuntimeError('No live frames')
 print('Three continuous cameras and real joints ready',flush=True);time.sleep(1)
 for i in range(3):
  args=SimpleNamespace(output=str(queue_root/'pending'),background_finalize_root=str(queue_root),background_finalize_info={'diagnostic_only':True},task='diagnostic_only_no_training',max_seconds=0,retain_native=False,controlled_sides=(),record_actions=False,adopt_camera_stream=True,camera_ids=list(received),camera_profiles=s.start.metadata['camera_profiles'])
  trigger=dict(sequence=0,session='passive-camera-validation',pc_monotonic_ns=time.monotonic_ns(),button_press_counts={},vr_connected=False)
  ep=mod.Episode(args,dict(zip(received,('head_color','right_color','left_color'))),trigger,client_factory=s.subscribe,episode_index=i+1)
  ep.start();limit=time.monotonic()+10
  while ep.state!='recording' and not ep.finished.is_set() and time.monotonic()<limit:time.sleep(.02)
  assert ep.state=='recording',ep.error
  time.sleep(3)
  stopped=time.monotonic();ep.stop('diagnostic_boundary');ep.join(20)
  assert not ep.is_alive() and ep.error is None,ep.error
  queued_ms=(time.monotonic()-stopped)*1000
  request=json.loads((ep.directory/queue.REQUEST).read_text())
  jobs.append((ep.directory.name,dict(boundary_ms=(boundaries[-1][0]-stopped)*1000,queued_ms=queued_ms)))
  assert ep.background_queued and not s.finished.is_set() and t.is_alive()
  print('Queued episode',i+1,queued_ms,flush=True)
 for job,row in jobs:
  limit=time.monotonic()+30
  while time.monotonic()<limit:
   saved=queue.read_json(queue_root/'jobs'/(job+'.json'),{})
   if saved.get('state')=='saved':break
   time.sleep(.1)
  assert saved.get('state')=='saved',saved
  folder=Path(saved['destination']);meta=json.loads((folder/'meta_info.json').read_text());end=json.loads((folder/'record/stream_end.json').read_text())
  assert meta['complete'] and meta['integrity']['record_count_matches_server']
  assert end['transport_continues'] and end['native_exit'] is None
  row.update(episode=str(folder),counts_match=True,rates={k:v.get('actual_hz') for k,v in meta['integrity']['cameras'].items()},joints=meta['integrity']['joints'],checkpoint=end['checkpoint_id'])
  results.append(row)
 previous={}
 for row in results:
  for name in ('head_color','left_color','right_color'):
   frames=[json.loads(v) for v in (Path(row['episode'])/'record'/(name+'_frames.jsonl')).read_text().splitlines()]
   seq=[v['sequence'] for v in frames]
   assert all(b>a for a,b in zip(seq,seq[1:]))
   assert name not in previous or seq[0]>previous[name]
   previous[name]=seq[-1]
 assert not failure,failure
 summary={'episodes':results,'failure':failure,'camera_max_receive_gap_ms':{k:max((b[0]-a[0])*1000 for a,b in zip(v,v[1:])) for k,v in received.items()},'camera_sequence_regressions':{k:sum(b[1]<=a[1] for a,b in zip(v,v[1:])) for k,v in received.items()},'hardware_streams_started':1,'saved_episodes_nonoverlapping':True}
 with open(ROOT/'process-queue-test-results.json','w') as f:json.dump(summary,f)
 print('SUMMARY',json.dumps({k:v for k,v in summary.items() if k!='episodes'}),flush=True)
finally:
 worker.terminate();worker.wait(10);c.request_stop();t.join(15);c.close()
 print('Transport ended after test:',bool(s.end),'error:',failure,flush=True)
